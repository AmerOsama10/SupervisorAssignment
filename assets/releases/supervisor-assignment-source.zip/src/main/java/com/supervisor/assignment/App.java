package com.supervisor.assignment;

import com.supervisor.assignment.ui.Launcher;

public class App {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
